  const button = document.getElementById("myButton");
  if (button) {
    button.addEventListener("click", function() {
      chrome.tabs.create({ url: "https://remix.ethereum.org" });
    });
  } else {
    
  }


function waitForElement(id, callback) {
const interval = setInterval(() => {
  const element = document.querySelector(`${id}`);
  if (element) {
    callback(element);
    clearInterval(interval);
  }
}, 100); 
}

waitForElement('[data-id="status-bar-container"]', function(element) {
  element.remove();
});

waitForElement('[data-id="newCodePastedModalDialogContainer-react"]', function(element) {
  element.remove();
});

waitForElement('[data-id="matomoModalModalDialogContainer-react"]', function(element) {
  element.remove();
});

waitForElement('[data-id="popupPanelPluginsContainer"]', function(element) {
  element.remove();
});




const checkbox = document.getElementById('checkbox1');

chrome.storage.sync.get('checkboxState', function(result) {
  if (result.checkboxState !== undefined) {
    checkbox.checked = result.checkboxState;
  }
});

if (checkbox) {
checkbox.addEventListener('change', function() {
  const isChecked = checkbox.checked;
  chrome.storage.sync.set({ 'checkboxState': isChecked }, function() {
  });
});

}
